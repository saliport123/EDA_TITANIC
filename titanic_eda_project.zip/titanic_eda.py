
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Load dataset
df = pd.read_csv('tested.csv')

# Create directory to save images
image_dir = 'images'
os.makedirs(image_dir, exist_ok=True)

# Set plot style
sns.set(style='whitegrid')

# Plot 1: Survival Count
plt.figure(figsize=(6,4))
sns.countplot(x='Survived', data=df, palette='pastel')
plt.title('Survival Count')
plt.xlabel('Survived (0 = No, 1 = Yes)')
plt.ylabel('Count')
plt.savefig(f'{image_dir}/survival_count.png')
plt.close()

# Plot 2: Survival by Sex
plt.figure(figsize=(6,4))
sns.countplot(x='Sex', hue='Survived', data=df, palette='Set2')
plt.title('Survival by Sex')
plt.xlabel('Sex')
plt.ylabel('Count')
plt.legend(title='Survived')
plt.savefig(f'{image_dir}/survival_by_sex.png')
plt.close()

# Plot 3: Age Distribution
plt.figure(figsize=(6,4))
sns.histplot(df['Age'].dropna(), bins=30, kde=True, color='skyblue')
plt.title('Age Distribution')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.savefig(f'{image_dir}/age_distribution.png')
plt.close()

# Plot 4: Survival by Passenger Class
plt.figure(figsize=(6,4))
sns.countplot(x='Pclass', hue='Survived', data=df, palette='coolwarm')
plt.title('Survival by Passenger Class')
plt.xlabel('Passenger Class')
plt.ylabel('Count')
plt.legend(title='Survived')
plt.savefig(f'{image_dir}/survival_by_pclass.png')
plt.close()
