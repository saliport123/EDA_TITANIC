
# Titanic Dataset - Exploratory Data Analysis (EDA)

This project performs an exploratory data analysis (EDA) on the Titanic dataset. It includes visualizations to understand how different features such as sex, class, and age affected survival rates.

## Files Included
- `tested.csv` - Titanic dataset used for analysis
- `titanic_eda.py` - Python script that performs EDA and generates visualizations
- `images/` - Folder containing all visualization plots

## Visualizations
- Survival count
- Survival by sex
- Age distribution
- Survival by passenger class

## How to Run
```bash
pip install pandas matplotlib seaborn
python titanic_eda.py
```

This will generate image files in the `images/` folder.
